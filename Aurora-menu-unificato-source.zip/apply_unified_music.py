#!/usr/bin/env python3
"""Apply a combined Spotify + YouTube Music menu to Aurora's merged library.

Designed for the nessli420/aurora repository, main branch around Nov 2026.
Idempotent: applying twice does not duplicate anything.
"""
from pathlib import Path
import sys

TARGET = Path('core/src/main/kotlin/com/aurora/music/data/MergedBackend.kt')
if not TARGET.is_file():
    raise SystemExit('Run from the root of a cloned nessli420/aurora repository.')
text = TARGET.read_text(encoding='utf-8')
if 'AURORA_COMBINED_MUSIC_MENU' in text:
    print('Already patched:', TARGET)
    raise SystemExit(0)


def replace_once(old: str, new: str):
    global text
    hits = text.count(old)
    if hits != 1:
        raise SystemExit(f'Patch not applied: expected 1 matching block, found {hits}: {old[:70]!r}')
    text = text.replace(old, new, 1)

replace_once('''    // library first, then each streaming catalogue on its own; a lone choice is no choice
    private fun <T> choices(make: (String, String) -> T, libraryId: String, libraryLabel: String, youtubeId: String): List<T> =
        if (nested) emptyList() else buildList {
            add(make(libraryId, libraryLabel))
            if (youtubeIndex >= 0) add(make(youtubeId, "YouTube Music"))
            if (spotifyIndex >= 0) add(make("spotify", "Spotify"))
            if (soundcloudIndex >= 0) add(make("soundcloud", "SoundCloud"))
        }.takeIf { it.size > 1 }.orEmpty()

    override val homeFeeds: List<HomeFeedChoice> get() = choices(::HomeFeedChoice, "library", "Library", "discovery")
    override val searchSources: List<SearchSourceChoice> get() = choices(::SearchSourceChoice, "library", "Local & servers", "discovery")
    override val libraryViews: List<LibraryViewChoice> get() = choices(::LibraryViewChoice, "library", "Local & servers", "youtube")
''', '''    // AURORA_COMBINED_MUSIC_MENU: one entry for YouTube Music + Spotify.
    // Leave SoundCloud and the local/server library separate. Wrapped IDs preserve each provider.
    private val musicIndices: List<Int> get() = listOf(youtubeIndex, spotifyIndex).filter { it >= 0 }.distinct()
    private val musicLabel: String get() = when {
        youtubeIndex >= 0 && spotifyIndex >= 0 -> "Spotify + YouTube Music"
        youtubeIndex >= 0 -> "YouTube Music"
        else -> "Spotify"
    }

    private fun <T> choices(make: (String, String) -> T, libraryId: String, libraryLabel: String): List<T> =
        if (nested) emptyList() else buildList {
            add(make(libraryId, libraryLabel))
            if (musicIndices.isNotEmpty()) add(make("music", musicLabel))
            if (soundcloudIndex >= 0) add(make("soundcloud", "SoundCloud"))
        }.takeIf { it.size > 1 }.orEmpty()

    override val homeFeeds: List<HomeFeedChoice> get() = choices(::HomeFeedChoice, "library", "Library")
    override val searchSources: List<SearchSourceChoice> get() = choices(::SearchSourceChoice, "library", "Local & servers")
    override val libraryViews: List<LibraryViewChoice> get() = choices(::LibraryViewChoice, "library", "Local & servers")
''')

replace_once('''                val picked = when (view) {
                    "library" -> sources.filterNot(::isCatalogue)
                    else -> listOfNotNull(sources.getOrNull(catalogueFor(view)))
                }
''', '''                val picked = when (view) {
                    "library" -> sources.filterNot(::isCatalogue)
                    "music" -> musicIndices.map { sources[it] }
                    else -> listOfNotNull(sources.getOrNull(catalogueFor(view)))
                }
''')

replace_once('''    override suspend fun home(feed: String): HomeData {
        val index = catalogueFor(feed)
        return if (index >= 0) sources[index].home().wrapHome(index) else home()
    }

    override suspend fun homePage(feed: String, continuation: String): HomeData {
        val index = catalogueFor(feed)
        return if (index >= 0) sources[index].homePage(continuation).wrapHome(index) else HomeData()
    }
''', '''    override suspend fun home(feed: String): HomeData {
        if (feed == "music") return combinedMusicHome()
        val index = catalogueFor(feed)
        return if (index >= 0) sources[index].home().wrapHome(index) else home()
    }

    override suspend fun homePage(feed: String, continuation: String): HomeData {
        if (feed == "music") return combinedMusicHome(decodeMusicContinuation(continuation))
        val index = catalogueFor(feed)
        return if (index >= 0) sources[index].homePage(continuation).wrapHome(index) else HomeData()
    }

    // Continuations are per provider, not interchangeable; keep each until it is exhausted.
    private fun encodeMusicContinuation(pages: List<Pair<Int, String>>): String? =
        pages.filter { it.second.isNotBlank() }.takeIf { it.isNotEmpty() }
            ?.joinToString("|", prefix = "music:") { (index, token) ->
                val encoded = java.util.Base64.getUrlEncoder().withoutPadding()
                    .encodeToString(token.toByteArray(Charsets.UTF_8))
                "$index:$encoded"
            }

    private fun decodeMusicContinuation(value: String): List<Pair<Int, String>> {
        if (!value.startsWith("music:")) return emptyList()
        return value.removePrefix("music:").split('|').mapNotNull { part ->
            val index = part.substringBefore(':').toIntOrNull() ?: return@mapNotNull null
            if (index !in musicIndices || ':' !in part) return@mapNotNull null
            val token = runCatching {
                String(java.util.Base64.getUrlDecoder().decode(part.substringAfter(':')), Charsets.UTF_8)
            }.getOrNull() ?: return@mapNotNull null
            (index to token).takeIf { token.isNotBlank() }
        }
    }

    private suspend fun combinedMusicHome(pages: List<Pair<Int, String>>? = null): HomeData {
        val requests = pages ?: musicIndices.map { it to "" }
        val responses = coroutineScope {
            requests.map { (index, token) -> async {
                index to try {
                    withTimeoutOrNull(SOURCE_TIMEOUT_MS) {
                        if (pages == null) sources[index].home() else sources[index].homePage(token)
                    }
                } catch (e: CancellationException) { throw e }
                catch (_: Exception) { null }
            } }.awaitAll()
        }
        val homes = responses.mapNotNull { (index, data) -> data?.let { index to it.wrapHome(index) } }
        return HomeData(
            newReleases = dedupAlbums(homes.flatMap { it.second.newReleases }),
            recentlyPlayed = dedupAlbums(homes.flatMap { it.second.recentlyPlayed }),
            mostPlayed = dedupAlbums(homes.flatMap { it.second.mostPlayed }),
            random = dedupAlbums(homes.flatMap { it.second.random }),
            playlists = homes.flatMap { it.second.playlists },
            artists = dedupArtists(homes.flatMap { it.second.artists }),
            starred = dedupSongs(homes.flatMap { it.second.starred }),
            sections = homes.flatMap { it.second.sections },
            continuation = encodeMusicContinuation(homes.mapNotNull { (index, data) ->
                data.continuation?.let { index to it }
            }),
        )
    }
''')

replace_once('''    override suspend fun search(query: String, source: String): SearchResults {
        // a missing catalogue falls back to the other one before the merged library
''', '''    override suspend fun search(query: String, source: String): SearchResults {
        if (source == "music") {
            val results = coroutineScope {
                musicIndices.map { index -> async {
                    index to try { withTimeoutOrNull(SOURCE_TIMEOUT_MS) { sources[index].search(query) } }
                    catch (e: CancellationException) { throw e }
                    catch (_: Exception) { null }
                } }.awaitAll()
            }
            val valid = results.mapNotNull { (index, result) -> result?.let { index to it } }
            return SearchResults(
                dedupSongs(valid.flatMap { (index, result) -> result.songs.map { it.wrap(index) } }),
                dedupAlbums(valid.flatMap { (index, result) -> result.albums.map { it.wrap(index) } }),
                dedupArtists(valid.flatMap { (index, result) -> result.artists.map { it.wrap(index) } }),
                valid.flatMap { (index, result) -> result.playlists.map { it.wrap(index) } },
            )
        }
        // a missing catalogue falls back to the other one before the merged library
''')

replace_once('''        val VIEW_IDS = setOf("library", "youtube", "spotify", "soundcloud")''', '''        val VIEW_IDS = setOf("library", "music", "youtube", "spotify", "soundcloud")''')

TARGET.write_text(text, encoding='utf-8')
print('Patched:', TARGET)
print('Unified menu: Spotify + YouTube Music (Home, Search, Library)')
